package takeout.yummy.Util;

/**
 * @Author: 161250127 TJW
 * @Description:
 * @Date: 2019/2/25
 */
public class SetMealReleaseInfo {

}
